import random
import prompt
from brain_games.scripts.greeting.welcome_user import welcome_user
import operator 


def main():
    name = welcome_user()
    print('What is the result of the expression?')
    n = 0
    while n < 3:
        num_1 = random.randint(1, 99)
        num_2 = random.randint(1, 99)
        action_list = ['+', '-', '*']
        dict1 = {'+': operator.add,
        '-': operator.sub,
        '*': operator.mul}
        random_operator = random.choice(action_list)
        expression = f'{num_1} {random_operator} {num_2}'
        print(f"Question:  {expression}") 
        answer = prompt.string("Your answer: ")
        if answer == f'{dict1.get(random_operator)(num_1, num_2)}':
            print('Correct!')
            n += 1
        else: 
            print(f'"{answer}" is wrong answer ;(. Correct answer was "{dict1.get(random_operator)(num_1, num_2)}".')
            break
    if n == 3:
        print(f'Congratulations, {name}!')
    else:
        print(f"Let's try again, {name}!")


main()