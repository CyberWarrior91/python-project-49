### Hexlet tests and linter status:
[![Actions Status](https://github.com/CyberWarrior91/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/CyberWarrior91/python-project-49/actions)
<a href="https://codeclimate.com/github/CyberWarrior91/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/0cdc54cb3725b457d0ca/maintainability" /></a>

Brain-even:
https://asciinema.org/a/bsXBegtf3To4zg9jgiFt4Tdvo

Brain-calc:
https://asciinema.org/a/Uxxw8uydQ8YaEiC9wrZ3OTpzy

Brain-gcd:
https://asciinema.org/a/zMFQINL7DvqAIBVDDwmc3ubG0
